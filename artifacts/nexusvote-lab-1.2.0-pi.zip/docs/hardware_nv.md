# Hardware próprio NV — terminal de votação de laboratório

> PROTÓTIPO INDEPENDENTE — LABORATÓRIO, NÃO OFICIAL. Espelho em escala de
> bancada da arquitetura pública UE2020/UE2022 (TPS-2023 Cotel, tabela JE,
> manual do mesário 2022, edital UE2028). Nada aqui é urna oficial.

## Arquitetura alvo (fase 1)

```
NV-TE-01 (eleitor)                NV-TM-01 (mesário)
Pi 4B + display + teclado        2º Pi (console do mesário)
  │ matrici. + alto-falante         │
  │                                 │  HABILITA (mesario.sock)
  ▼                                 ▼
núcleo C++ + canal Rust ◄──interlock──► Habilitador (token 5min)
  │ journal + hw-events.jsonl
  ▼
UPS HAT + RTC DS3231 + ATECC + tamper + lacres
```

Espelho oficial → nosso lab:

| Oficial (UE2020/22) | NV fase 1 | Código |
|---|---|---|
| TE + TM separados | 2 Pis, TM via `mesario.sock` | `src/lab/mesario_daemon.*` |
| Teclado cifrado (MSTE) | Matricial GPIO (fase 2); parser pronto | `nv-hal Key::parse` |
| MSE corta energia | `power_daemon` + flag `QUIESCE` | `rust/crates/nv-power-daemon` |
| Bateria LiFePO4 9Ah + LEDs | UPS HAT + `power.rs` (sysfs) | `nv-hal/src/power.rs` |
| RTC com bateria | DS3231 → `rtc0`; autoridade + ata | `nv-hal/src/rtc.rs`, `src/core/clock.*` |
| Assinatura/ata | `session.json: clock_trusted` + `events.log` | `src/core/session.cpp` |
| Cerimônia de lacração | Lacres numerados + `docs` (fase 2: PKI) | este arquivo |
| Mídia MR selada | Bundle + QR (fase C: chave cerimônia) | `audit_export`, `PaperBu` |

## BOM fase 1 (~R$1.500, 2 terminais)

- 2× Raspberry Pi 4B 2GB + fonte 5V/3A + microSD 32GB (~R$900).
- 1× display 7–10" HDMI usado (~R$300) + teclado matricial 4×4 (~R$25).
- 1× RTC DS3231 (~R$25) + 1× UPS HAT + bateria (~R$150).
- 1× ATECC608 (~R$40) + tamper-switches + lacres (~R$30).
- Chave liga/desliga, LEDs, cabos, caixa provisória.

Fase 2 (fora do teto): impressora térmica USB, gabinete final, 2º display.

## Bancada (sem comprar nada, hoje)

- `NV_HAL_FAKE_POWER=mains|battery:<pct>|critical` e `NV_HAL_FAKE_RTC=<epoch>`
  exercitam quiesce + RTC nos testes (`cargo test -p nv-hal`).
- `nv-power-daemon <workdir>`: escreve `hw-events.jsonl` (boot, mains_lost,
  power_critical + flag `QUIESCE`, rtc_untrusted); `NV_HAL_POLL_MS` acelera.
- `scripts/test_os_real.sh`: checa `rtc0`, `power_supply`, relógio, fsync.
- Queda de energia: journal append+fsync por voto só perde o voto em curso;
  `QUIESCE` manda fechar a sessão; tudo em ata.

## Lacres e ata (procedimento)

1. Anotar números dos lacres do gabinete + mídia na ata de abertura.
2. Zerésima impressa no envelope com os lacres.
3. Qualquer abertura: evento `tamper` (fase 2, switch) + ata + nova zerésima.
4. Encerramento: 5 vias BU assinadas + 1 via retida p/ conferência no portal lab.
