# Hardware próprio NV — fiação real Pi 4B (código real)

> PROTÓTIPO INDEPENDENTE — LABORATÓRIO, NÃO OFICIAL.

Alvo fixo (decisão usuário): **2× Raspberry Pi 4B + display HDMI 7–10" + teclado membrana 4×4**.

## 1. Teclado membrana 4×4 → gpio-matrix-keypad (kernel, sem userspace GPIO)

```
Membrana 4x4 (8 pinos, da esquerda p/ direita com membrana de frente):
  R1 R2 R3 R4 C1 C2 C3 C4
   |  |  |  |  |  |  |  |
  G5 G6 G13 G19 G12 G16 G20 G21 (BCM)

Mapa físico:
  R1: 1 2 3 A     A=BRANCO
  R2: 4 5 6 B     B=CORRIGE
  R3: 7 8 9 C     C=CONFIRMA
  R4: * 0 # D     *=cancela-mesário, #=confirma-alt, D=reserva
```

* Driver: `matrix-keypad` (`CONFIG_KEYBOARD_MATRIX=m`, já no kernel Pi).
* Overlay: `overlays/nv-keypad-4x4.dts` → `/boot/firmware/overlays/nv-keypad-4x4.dtbo`.
* `config.txt`: `dtoverlay=nv-keypad-4x4` + `debounce-delay-ms=20`.
* Symlink estável: `/dev/input/nv-keypad` via udev (ver `systemd/99-nv-keypad.rules`).
* Semântica BRANCO/CORRIGE/CONFIRMA é userspace (`nv-hal keypad_evdev`), kernel entrega `KEY_1..KEY_0, KEY_A/B/C/D`.

Validação física obrigatória (sem fake):

```bash
dmesg | grep -i matrix
ls -l /dev/input/nv-keypad /dev/input/event*
evtest /dev/input/nv-keypad   # pressionar 0-9,A,B,C,D: ver EV_KEY press/release
```

## 2. Display HDMI 800×480

```
Display HDMI genérico 7" 800x480 ou 10" 1024x600 → HDMI0 do Pi TE.
Touch USB (se houver) → USB2, evdev /dev/input/eventX.
```

`config.txt` (KMS Bookworm):

```ini
hdmi_force_hotplug=1
hdmi_group=2
hdmi_mode=87
hdmi_cvt 800 480 60 6 0 0 0
hdmi_drive=2
dtoverlay=vc4-kms-v3d
max_framebuffers=2
```

App Qt roda `QT_QPA_PLATFORM=eglfs` (sem X11). Fallback `linuxfb:/dev/fb0`.
Ver `scripts/install-pi.sh` e `systemd/nexusvote-qt.service`.

## 3. Som real (2 caminhos, sem QApplication::beep)

1. **HDMI ALSA**: `assets/sounds/confirma.wav` (2 pulsos 2kHz 120ms) + `fim.wav`
   (3 pulsos 250ms), tocados via `aplay -D plughw:0,0` (Lite sem Pulse).
2. **Piezo PWM GPIO18** (pino físico 12): `dtoverlay=pwm,pin=18,func=2`,
   `/sys/class/pwm/pwmchip0/pwm0` — espelha os pulsos junto com HDMI.
   Sem overlay: HDMI cobre sozinho, piezo retorna erro honesto (sem fingir).

```ini
dtparam=audio=on
dtoverlay=pwm,pin=18,func=2
```

Teste: `speaker-test -c2 -D plughw:0,0 -t sine -f 880 -l1` + `aplay assets/sounds/confirma.wav`.

## 4. RTC DS3231 (tempo autoritativo) + UPS HAT

```
DS3231: 3V3(pin1)→VCC, GND(pin6)→GND, GPIO2(pin3)→SDA, GPIO3(pin5)→SCL + CR2032.
config.txt: dtparam=i2c_arm=on + dtoverlay=i2c-rtc,ds3231
```

* Kernel cria `/dev/rtc0` + `/sys/class/rtc/rtc0/since_epoch` (lido por `nv-hal rtc`).
* `timedatectl set-ntp false` + purge `fake-hwclock`: RTC é autoridade.
* UPS HAT: se expõe `/sys/class/power_supply/*` o `nv-hal power` já lê;
  se só I2C (0x36/0x42), `nv-power-daemon` registra em `hw-events.jsonl`.
* Limiar: bateria ≤5% → `QUIESCE` → fecha sessão (sem habilitar ninguém).

## 5. Impressora térmica USB 58/80mm (driver nativo Pi)

* Ligação: USB-OTG direto no Pi (`/dev/usb/lp0`, grupo `lp`).
* Protocolo: ESC/POS cru via `std::fs` (`nv-hal printer`): `ESC @`, `ESC t 19`
  (PC858 PT-BR), texto 32 cols, QR firmware `GS ( k`, corte `GS V B 0`.
* Sem impressora: `IMPRESSORA-AUSENTE` honesto → segue QR na tela + ata.
  Falha no meio: `FALHA #n` → reimprime mesma via (ViaFlow no papel C++).
* Regra udev: `SUBSYSTEM=="usb", ATTR{idVendor}=="...", MODE="0660", GROUP="lp"`
  (ajustar VID/PID da sua unidade) + usuário `urna` no grupo `lp`.

## 6. Segurança física

* ATECC608 (I2C 0x60) fase 2; sem ele = `DEGRADED` documentado.
* Tamper-switch na tampa → GPIO (fase 2, evento `tamper` em `hw-events.jsonl`).
* Lacres numerados + ata de abertura/encerramento (ver `docs/hardware_nv.md`).
